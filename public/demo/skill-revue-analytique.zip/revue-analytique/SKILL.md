---
name: revue-analytique
description: Revue analytique d'une balance N/N-1 pour un auditeur : calcule les écarts, retient les comptes qui dépassent deux seuils (euros et %), rédige une question au client par compte retenu. Version de démonstration, provisoire.
---

# Revue analytique (version de démonstration)

## Règles
1. Écart = solde N - solde N-1 ; soldes au débit en positif, au crédit en négatif.
2. Retenir un compte seulement s'il atteint le seuil en euros ET le seuil en %. Un compte parti de zéro : seuil en euros seul.
3. Pour chaque compte retenu : une question au client et le document justificatif à demander. Ne jamais conclure.
4. Reprendre les montants tels quels, sans arrondir ; ne rien inventer sur l'entité.

## Sortie
Une ligne par compte : compte, libellé, solde N, solde N-1, écart en euros et en %, question au client, document à demander.
